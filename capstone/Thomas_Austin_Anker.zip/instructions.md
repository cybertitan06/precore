# Setup Instructions
Setup your WireGuard VPN access, and then SSH on to the `foothold` machine to get started with the capstone exercise. 

```bash
sudo mv ./wg0.conf /etc/wireguard/wg0.conf
sudo wg-quick up wg0
chmod 600 ./foothold.key
ssh -i ./foothold.key foothold@10.5.5.1
```
